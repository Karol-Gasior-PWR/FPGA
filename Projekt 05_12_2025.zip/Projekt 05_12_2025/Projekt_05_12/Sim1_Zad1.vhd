-- Testbench created online at:
--   https://www.doulos.com/knowhow/perl/vhdl-testbench-creation-using-perl/
-- Copyright Doulos Ltd

library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;


entity Zadanie1_tb is
end;

architecture bench of Zadanie1_tb is

  component Zadanie1
    Port (
      X : in STD_LOGIC; 
      CE : in STD_LOGIC;
      CLK : in STD_LOGIC;
      RST : in STD_LOGIC;
      Y : out STD_LOGIC
     );
  end component;

  signal X: STD_LOGIC := '0';
  signal CE: STD_LOGIC := '1';
  signal CLK: STD_LOGIC := '0';
  signal RST: STD_LOGIC := '0';
  signal Y: STD_LOGIC ;

  constant Clk_Period : DELAY_LENGTH :=1 us/ 40;
  constant Vec1: STD_LOGIC_VECTOR (0 to 20) := "101001100101001101101";

  signal stop_the_clock: boolean;

begin

  uut: Zadanie1 port map ( X   => X,
                           CE  => CE,
                           CLK => CLK,
                           RST => RST,
                           Y   => Y );


    Clk <= not CLK after Clk_Period / 2;
  stimulus: process
  begin
  wait for 2.5 ns;
     for i in 0 to 20 loop
     
         x <= VEC1(i);
         wait for CLK_PERIOD;


             
    end loop;
    stop_the_clock <= true;
    wait;
  end process;


end;
  
 