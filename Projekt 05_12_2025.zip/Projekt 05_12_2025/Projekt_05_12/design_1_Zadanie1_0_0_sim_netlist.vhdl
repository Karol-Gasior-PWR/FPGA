-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- --------------------------------------------------------------------------------
-- Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
-- Date        : Fri Dec  5 10:35:07 2025
-- Host        : Lab016-09 running 64-bit major release  (build 9200)
-- Command     : write_vhdl -force -mode funcsim
--               c:/Users/lab/Desktop/05_12_Projekt/project_1/project_1.gen/sources_1/bd/design_1/ip/design_1_Zadanie1_0_0/design_1_Zadanie1_0_0_sim_netlist.vhdl
-- Design      : design_1_Zadanie1_0_0
-- Purpose     : This VHDL netlist is a functional simulation representation of the design and should not be modified or
--               synthesized. This netlist cannot be used for SDF annotated simulation.
-- Device      : xczu3eg-sfvc784-2-e
-- --------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_Zadanie1_0_0_Zadanie1 is
  port (
    Y : out STD_LOGIC;
    RST : in STD_LOGIC;
    X : in STD_LOGIC;
    CE : in STD_LOGIC;
    CLK : in STD_LOGIC
  );
  attribute ORIG_REF_NAME : string;
  attribute ORIG_REF_NAME of design_1_Zadanie1_0_0_Zadanie1 : entity is "Zadanie1";
end design_1_Zadanie1_0_0_Zadanie1;

architecture STRUCTURE of design_1_Zadanie1_0_0_Zadanie1 is
  signal \FSM_sequential_state[0]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[1]_i_1_n_0\ : STD_LOGIC;
  signal \FSM_sequential_state[2]_i_1_n_0\ : STD_LOGIC;
  signal state : STD_LOGIC_VECTOR ( 2 downto 0 );
  attribute SOFT_HLUTNM : string;
  attribute SOFT_HLUTNM of \FSM_sequential_state[0]_i_1\ : label is "soft_lutpair1";
  attribute SOFT_HLUTNM of \FSM_sequential_state[1]_i_1\ : label is "soft_lutpair0";
  attribute SOFT_HLUTNM of \FSM_sequential_state[2]_i_1\ : label is "soft_lutpair0";
  attribute FSM_ENCODED_STATES : string;
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[0]\ : label is "a:000,d:011,e:100,f:110,s:101,b:001,c:010";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[1]\ : label is "a:000,d:011,e:100,f:110,s:101,b:001,c:010";
  attribute FSM_ENCODED_STATES of \FSM_sequential_state_reg[2]\ : label is "a:000,d:011,e:100,f:110,s:101,b:001,c:010";
  attribute SOFT_HLUTNM of \Y__0\ : label is "soft_lutpair1";
begin
\FSM_sequential_state[0]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"05515001"
    )
        port map (
      I0 => RST,
      I1 => state(0),
      I2 => state(1),
      I3 => state(2),
      I4 => X,
      O => \FSM_sequential_state[0]_i_1_n_0\
    );
\FSM_sequential_state[1]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"41440010"
    )
        port map (
      I0 => RST,
      I1 => state(1),
      I2 => state(2),
      I3 => state(0),
      I4 => X,
      O => \FSM_sequential_state[1]_i_1_n_0\
    );
\FSM_sequential_state[2]_i_1\: unisim.vcomponents.LUT5
    generic map(
      INIT => X"14041110"
    )
        port map (
      I0 => RST,
      I1 => state(1),
      I2 => state(2),
      I3 => X,
      I4 => state(0),
      O => \FSM_sequential_state[2]_i_1_n_0\
    );
\FSM_sequential_state_reg[0]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => CE,
      D => \FSM_sequential_state[0]_i_1_n_0\,
      Q => state(0),
      R => '0'
    );
\FSM_sequential_state_reg[1]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '0'
    )
        port map (
      C => CLK,
      CE => CE,
      D => \FSM_sequential_state[1]_i_1_n_0\,
      Q => state(1),
      R => '0'
    );
\FSM_sequential_state_reg[2]\: unisim.vcomponents.FDRE
    generic map(
      INIT => '1'
    )
        port map (
      C => CLK,
      CE => CE,
      D => \FSM_sequential_state[2]_i_1_n_0\,
      Q => state(2),
      R => '0'
    );
\Y__0\: unisim.vcomponents.LUT3
    generic map(
      INIT => X"40"
    )
        port map (
      I0 => state(0),
      I1 => state(2),
      I2 => state(1),
      O => Y
    );
end STRUCTURE;
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1_Zadanie1_0_0 is
  port (
    X : in STD_LOGIC;
    CE : in STD_LOGIC;
    CLK : in STD_LOGIC;
    RST : in STD_LOGIC;
    Y : out STD_LOGIC
  );
  attribute NotValidForBitStream : boolean;
  attribute NotValidForBitStream of design_1_Zadanie1_0_0 : entity is true;
  attribute CHECK_LICENSE_TYPE : string;
  attribute CHECK_LICENSE_TYPE of design_1_Zadanie1_0_0 : entity is "design_1_Zadanie1_0_0,Zadanie1,{}";
  attribute downgradeipidentifiedwarnings : string;
  attribute downgradeipidentifiedwarnings of design_1_Zadanie1_0_0 : entity is "yes";
  attribute ip_definition_source : string;
  attribute ip_definition_source of design_1_Zadanie1_0_0 : entity is "module_ref";
  attribute x_core_info : string;
  attribute x_core_info of design_1_Zadanie1_0_0 : entity is "Zadanie1,Vivado 2025.1";
end design_1_Zadanie1_0_0;

architecture STRUCTURE of design_1_Zadanie1_0_0 is
  attribute x_interface_info : string;
  attribute x_interface_info of CLK : signal is "xilinx.com:signal:clock:1.0 CLK CLK";
  attribute x_interface_mode : string;
  attribute x_interface_mode of CLK : signal is "slave CLK";
  attribute x_interface_parameter : string;
  attribute x_interface_parameter of CLK : signal is "XIL_INTERFACENAME CLK, ASSOCIATED_RESET RST, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, INSERT_VIP 0";
  attribute x_interface_info of RST : signal is "xilinx.com:signal:reset:1.0 RST RST";
  attribute x_interface_mode of RST : signal is "slave RST";
  attribute x_interface_parameter of RST : signal is "XIL_INTERFACENAME RST, POLARITY ACTIVE_LOW, INSERT_VIP 0";
begin
U0: entity work.design_1_Zadanie1_0_0_Zadanie1
     port map (
      CE => CE,
      CLK => CLK,
      RST => RST,
      X => X,
      Y => Y
    );
end STRUCTURE;
