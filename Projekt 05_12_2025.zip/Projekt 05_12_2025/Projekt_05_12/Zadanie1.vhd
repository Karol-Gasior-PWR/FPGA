----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05.12.2025 08:32:37
-- Design Name: 
-- Module Name: Zadanie1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Zadanie1 is
  Port (
    X : in STD_LOGIC; 
    CE : in STD_LOGIC;
    CLK : in STD_LOGIC;
    RST : in STD_LOGIC;
    Y : out STD_LOGIC
   );
  
  
end Zadanie1;

architecture Behavioral of Zadanie1 is
    type state_type is (S, A, B, C, D, E, F);
    signal state, next_state : state_type;

begin
    process1 : process( Clk )
    begin
        if rising_edge( Clk ) and CE = '1' then
            if RST = '1' then
                state <= A;
             else
                state <= next_state;
             end if;
         end if;
    end process process1;
    
   
process_2: process (state, X)
    begin
    next_state <= state;
        case state is
            when S => 
                if X = '1' then
                    next_state <= S;
                else 
                    next_state <= A;
                end if; 
               -------------------------------- 
            when A => 
                if X = '1' then
                    next_state <= S;
                else 
                    next_state <= B;
                end if; 
               --------------------------------               
            when B => 
                if X = '1' then
                    next_state <= C;
                else 
                    next_state <= A;
                end if; 
               --------------------------------                   
            when C => 
                if X = '1' then
                    next_state <= D;
                else 
                    next_state <= A;
                end if; 
               --------------------------------               
            when D => 
                if X = '1' then
                    next_state <= S;
                else 
                    next_state <= E;
                end if; 
               --------------------------------
            when E => 
                if X = '1' then
                    next_state <= S;
                else 
                    next_state <= F;
                end if; 
               --------------------------------
            when F => 
                if X = '1' then
                    next_state <= C;
                else 
                    next_state <= B;
                end if; 
               --------------------------------                            
                
            when others => next_state <= S;
        end case;
    end process process_2;
   
-- In place of process3:
 y <= '1' when state = F
 else '0';


end Behavioral;
