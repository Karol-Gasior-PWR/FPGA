--Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
--Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
--Date        : Fri Dec  5 10:54:54 2025
--Host        : Lab016-09 running 64-bit major release  (build 9200)
--Command     : generate_target design_1.bd
--Design      : design_1
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity design_1 is
  port (
    ROT_A : in STD_LOGIC;
    ROT_B : in STD_LOGIC;
    clk_100mhz_clk_n : in STD_LOGIC;
    clk_100mhz_clk_p : in STD_LOGIC;
    reset : in STD_LOGIC;
    wyjscie : out STD_LOGIC
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of design_1 : entity is "design_1,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=design_1,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=4,numReposBlks=4,numNonXlnxBlks=1,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=2,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of design_1 : entity is "design_1.hwdef";
end design_1;

architecture STRUCTURE of design_1 is
  component design_1_RotaryEnc_0_0 is
  port (
    ROT_A : in STD_LOGIC;
    ROT_B : in STD_LOGIC;
    Clk : in STD_LOGIC;
    RotL : out STD_LOGIC;
    RotR : out STD_LOGIC
  );
  end component design_1_RotaryEnc_0_0;
  component design_1_clk_wiz_0_0 is
  port (
    clk_in1_p : in STD_LOGIC;
    clk_in1_n : in STD_LOGIC;
    reset : in STD_LOGIC;
    clk_out1 : out STD_LOGIC;
    locked : out STD_LOGIC
  );
  end component design_1_clk_wiz_0_0;
  component design_1_Zadanie1_0_0 is
  port (
    X : in STD_LOGIC;
    CE : in STD_LOGIC;
    CLK : in STD_LOGIC;
    RST : in STD_LOGIC;
    Y : out STD_LOGIC
  );
  end component design_1_Zadanie1_0_0;
  component design_1_nasz_or_0_0 is
  port (
    a : in STD_LOGIC;
    b : in STD_LOGIC;
    y : out STD_LOGIC
  );
  end component design_1_nasz_or_0_0;
  signal RotaryEnc_0_RotL : STD_LOGIC;
  signal RotaryEnc_0_RotR : STD_LOGIC;
  signal clk_wiz_0_clk_out1 : STD_LOGIC;
  signal nasz_or_0_y : STD_LOGIC;
  signal NLW_clk_wiz_0_locked_UNCONNECTED : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk_100mhz_clk_n : signal is "xilinx.com:interface:diff_clock:1.0 clk_100mhz CLK_N";
  attribute X_INTERFACE_MODE : string;
  attribute X_INTERFACE_MODE of clk_100mhz_clk_n : signal is "Slave";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk_100mhz_clk_n : signal is "XIL_INTERFACENAME clk_100mhz, CAN_DEBUG false, FREQ_HZ 100000000";
  attribute X_INTERFACE_INFO of clk_100mhz_clk_p : signal is "xilinx.com:interface:diff_clock:1.0 clk_100mhz CLK_P";
  attribute X_INTERFACE_INFO of reset : signal is "xilinx.com:signal:reset:1.0 RST.RESET RST";
  attribute X_INTERFACE_PARAMETER of reset : signal is "XIL_INTERFACENAME RST.RESET, INSERT_VIP 0, POLARITY ACTIVE_LOW";
begin
RotaryEnc_0: component design_1_RotaryEnc_0_0
     port map (
      Clk => clk_wiz_0_clk_out1,
      ROT_A => ROT_A,
      ROT_B => ROT_B,
      RotL => RotaryEnc_0_RotL,
      RotR => RotaryEnc_0_RotR
    );
Zadanie1_0: component design_1_Zadanie1_0_0
     port map (
      CE => nasz_or_0_y,
      CLK => clk_wiz_0_clk_out1,
      RST => reset,
      X => RotaryEnc_0_RotR,
      Y => wyjscie
    );
clk_wiz_0: component design_1_clk_wiz_0_0
     port map (
      clk_in1_n => clk_100mhz_clk_n,
      clk_in1_p => clk_100mhz_clk_p,
      clk_out1 => clk_wiz_0_clk_out1,
      locked => NLW_clk_wiz_0_locked_UNCONNECTED,
      reset => '0'
    );
nasz_or_0: component design_1_nasz_or_0_0
     port map (
      a => RotaryEnc_0_RotL,
      b => RotaryEnc_0_RotR,
      y => nasz_or_0_y
    );
end STRUCTURE;
